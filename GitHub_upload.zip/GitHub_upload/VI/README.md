# Phần làm việc của Vĩ

`VI/code/` chứa mã chia theo step; `VI/notes/` ghi mục đích và kết quả của từng step; `VI/figures/` chứa hình xuất cho báo cáo.

Xem [luồng nhiệm vụ](notes/luong_nhiem_vu.md) để biết các step phụ thuộc nhau thế nào. Mỗi step có một ghi chú **vì sao làm** trước khi có mã.

| Step hiện có | Ghi chú | Mã |
|---|---|---|
| 0 — NACA 2412 | [step0_naca2412.md](notes/step0_naca2412.md) | [step0_naca2412.py](code/step0_naca2412.py) |
| 1 — Hình học cánh 3D | [step1_wing_geometry.md](notes/step1_wing_geometry.md) | [step1_wing_geometry.py](code/step1_wing_geometry.py) |
| 2 — Diện tích cánh | [step2_wing_area.md](notes/step2_wing_area.md) | [step2_wing_area.py](code/step2_wing_area.py) |
| 3 — Hình học thân | [step3_fuselage_geometry.md](notes/step3_fuselage_geometry.md) | [step3_fuselage_geometry.py](code/step3_fuselage_geometry.py) |
| 4 — Thể tích, khối lượng thân | [step4_fuselage_integrals.md](notes/step4_fuselage_integrals.md) | [step4_fuselage_integrals.py](code/step4_fuselage_integrals.py) |
| 5 — Vẽ hình | [step5_visualization.md](notes/step5_visualization.md) | [step5_visualization.py](code/step5_visualization.py) |
| 6 — Kiểm chứng và ghép khí động | [step6_validation.md](notes/step6_validation.md) | [step6_validation.py](code/step6_validation.py) |
| 7 — Dashboard thay đổi thông số | [step7_dashboard.md](notes/step7_dashboard.md) | [step7_dashboard.py](code/step7_dashboard.py) |

Chạy các step từ thư mục `D:\HOC\GT2`:

```powershell
py -3 VI\code\step0_naca2412.py
py -3 VI\code\step1_wing_geometry.py
py -3 VI\code\step2_wing_area.py
py -3 VI\code\step3_fuselage_geometry.py
py -3 VI\code\step4_fuselage_integrals.py
py -3 VI\code\step5_visualization.py
py -3 VI\code\step6_validation.py
```

Chạy Step 7 từ `D:\HOC\GT2` rồi mở địa chỉ Streamlit hiện trong Terminal:

```powershell
& '.\Integral-Applications-in-Aircraft-Modeling---GT2-main\Integral-Applications-in-Aircraft-Modeling---GT2-main\.venv\Scripts\python.exe' -m streamlit run VI\code\step7_dashboard.py
```

Trong Step 7, tab **Kiểm chứng** chia thành phần Vĩ (hình học cánh, thân) và phần Khải (khí động cánh phẳng tham chiếu). Mỗi hàng có số tính được và số đối chiếu; không có điểm tổng `7/7 đạt` hoặc `14/14 đạt`. Lực nâng được so riêng với trọng lượng vỏ thân.

Bài mẫu đầy đủ để đối chiếu nằm ở [thư mục dự án](../Integral-Applications-in-Aircraft-Modeling---GT2-main/Integral-Applications-in-Aircraft-Modeling---GT2-main/README.md). Phần bạn tự chỉnh và hiểu có thể ghi lại trong [nhật ký](notes/nhat_ky.md).

Hình mặt cắt cho thấy cánh đi xuyên qua thân: [wing_fuselage_intersection.png](figures/wing_fuselage_intersection.png).
Hình 3D tô đỏ phần cánh nằm trong thân: [aircraft_intersection_3d.png](figures/aircraft_intersection_3d.png).
