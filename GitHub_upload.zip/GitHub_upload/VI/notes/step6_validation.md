# Step 6 — Kiểm chứng và nối với phần khí động

## Vì sao làm step này?

Các step trước cho ra nhiều kết quả riêng. Step 6 kiểm tra xem chúng có nhất quán với công thức đơn giản, có ổn định khi tăng độ mịn lưới và có dùng được trong phần tích phân lực của Khải hay không.

## Các đối chiếu

- Step 0–1: độ cong giữa NACA 2412 tại `u=0.4` bằng `0.02`; dây cung ở gốc và mút bằng tham số đầu vào.
- Step 2: diện tích hình chiếu số khớp `S=b(c_root+c_tip)/2`; diện tích bề mặt ổn định khi tăng lưới và lớn hơn `2S`.
- Step 3–4: bán kính ở mũi/cuối đuôi bằng 0, ở thân giữa bằng `R`; thể tích đặc khớp công thức ba đoạn; hai cách tích phân số cho thể tích vỏ gần nhau.
- Step 5: sáu file hình đã được xuất vào `VI/figures/`.
- Phần của Khải: chuyển hàm `wing_point()` của Step 1 thành giao diện `surface(u,v,side)` nhận mảng; truyền đối tượng cánh đó vào `compute_aero_forces()` của `src/aero.py`. Kiểm tra diện tích tham chiếu `S_ref` khớp Step 2 và kết quả lực là số hữu hạn.

Chương trình đọc tham số từ `params.yaml` của dự án mẫu. Giao diện nối chỉ nằm trong Step 6; không sửa `src/aero.py`. Các kiểm tra lực nâng và lực cản dương áp dụng cho bộ tham số mặc định của bài.

Kết quả với tham số mẫu: 10/10 phép kiểm tra đạt; `S_ref=13.5 m²`, lực nâng `L≈15850.70 N`, lực cản `D≈599.75 N`. Khi đối chiếu thêm trong môi trường `.venv` của dự án, cánh trong `VI` và `src.wing.WingModel` cho đúng cùng hai giá trị lực này. Đây là kết quả của mô hình khí động giả thiết trong bài, không phải phép đo thực nghiệm.

Các phép kiểm tra trên xác nhận mã và công thức nhất quán; chúng không loại bỏ phần cánh xuyên qua thân hay mô phỏng tương tác khí động giữa cánh và thân.

**File mã:** [step6_validation.py](../code/step6_validation.py).
