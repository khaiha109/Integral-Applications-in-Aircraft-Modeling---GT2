# Step 4 — Thể tích và khối lượng thân

## Vì sao làm step này?

Step 3 đã cho bán kính `r(x)` ở mỗi vị trí dọc thân. Step 4 dùng bán kính đó để tính lượng không gian bên trong thân và lượng vật liệu cần làm lớp vỏ. Khối lượng thân được tính từ thể tích vỏ, không phải thể tích thân đặc.

## Công thức

Trong tọa độ trụ, phần tử thể tích là `s ds dθ dx`. Tích phân theo `s` và `θ` trước cho:

- Thân đặc: `V_đặc = ∫₀ᴸ πr(x)² dx`.
- Vỏ dày `t` theo phương bán kính: `V_vỏ = ∫₀ᴸ π[r(x)² − max(r(x)−t, 0)²] dx`.
- Khối lượng vỏ: `m = ρV_vỏ`, với `ρ` là khối lượng riêng vật liệu.

Tích phân số dùng quy tắc Simpson trên từng đoạn mũi, giữa và đuôi. Thể tích thân đặc được đối chiếu với công thức `πR²[N/2 + (L−N−T) + 3T/8]`; thể tích vỏ được đối chiếu thêm bằng quy tắc hình thang.

## Tham số và đầu ra

Ví dụ lấy từ `params.yaml`: `L=8 m`, `R=0.7 m`, `N=1.5 m`, `T=2.5 m`, vỏ dày `t=0.003 m`, khối lượng riêng `ρ=2700 kg/m³`. Hàm trả về thể tích bằng `m³` và khối lượng bằng `kg`. `t` là bề dày theo bán kính; đây là mô hình đơn giản, chưa tính khung sườn và thiết bị.

Kết quả mẫu: thân đặc `8.75523 m³` (khớp công thức), vỏ `0.08165 m³`, khối lượng vỏ `220.45 kg`. Trường hợp mũi và đuôi dài bằng 0 cũng được kiểm tra với công thức thể tích hình trụ `πR²L`.

**File mã:** [step4_fuselage_integrals.py](../code/step4_fuselage_integrals.py).
