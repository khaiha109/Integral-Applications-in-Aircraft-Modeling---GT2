# Step 2 — Diện tích cánh

## Vì sao làm step này?

Step 1 cho tọa độ từng điểm trên cánh. Step 2 dùng các điểm đó để tính diện tích. Cần phân biệt diện tích **hình chiếu** khi nhìn từ trên xuống (dùng trong công thức lực nâng) với diện tích **bề mặt thật** của cả mặt trên và mặt dưới.

## Cách tính

- Diện tích hình chiếu: `S = ∫∫ c(y) du dy = ∫ c(y) dy`, với `0 ≤ u ≤ 1` và `-b/2 ≤ y ≤ b/2`. Tính số bằng cách chia sải cánh thành các dải nhỏ; đối chiếu công thức hình thang `S = b(c_root + c_tip)/2`.
- Diện tích bề mặt: chia mỗi mặt cánh thành các ô nhỏ. Bốn điểm góc của một ô lấy từ `wing_point()` ở Step 1; tách ô thành hai tam giác rồi cộng diện tích. Đây là cách xấp xỉ tích phân mặt `A = ∫∫ |r_u × r_y| du dy`.
- Lưới càng mịn, kết quả diện tích bề mặt càng ổn định. `n_chord` là số ô dọc dây cung, `n_span` là số ô trên nửa sải cánh. Tính nửa cánh rồi nhân đôi vì hai bên đối xứng.

## Kết quả mong đợi

Với `b=10 m`, `c_root=1.8 m`, `c_tip=0.9 m`, diện tích hình chiếu là `13.5 m²`. Lưới 200 × 100 ô trên nửa cánh cho mặt trên khoảng `13.8675 m²`, mặt dưới `13.6972 m²`, tổng `27.5648 m²`. Tổng này lớn hơn `2S = 27 m²` vì mặt cánh có độ cong.

Các kích thước trên lấy từ `params.yaml` của bài mẫu, không được tính từ mã NACA 2412.

**File mã:** [step2_wing_area.py](../code/step2_wing_area.py).
