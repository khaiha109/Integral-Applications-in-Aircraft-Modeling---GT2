# Step 5 — Vẽ hình

## Vì sao làm step này?

Step 0–4 đã tính được biên dạng, tọa độ cánh và thân, diện tích, thể tích. Hình giúp nhìn lại hình học đã dựng và cung cấp ảnh cho báo cáo. Step này lấy tọa độ từ các step trước, không tính lại diện tích hay khối lượng.

## Hình xuất ra

- `airfoil_profile.png`: mặt trên và mặt dưới NACA 2412 từ Step 0.
- `wing_3d.png`: hai mặt cánh từ Step 1.
- `fuselage_3d.png`: thân tròn xoay từ Step 3.
- `aircraft_3d.png`: ghép cánh và thân để minh họa hình dạng tổng thể.
- `wing_fuselage_intersection.png`: mặt cắt nhìn từ phía trước tại vị trí gắn cánh; tô màu phần cánh nằm trong thân để thấy rõ hai mô hình đang giao nhau.
- `aircraft_intersection_3d.png`: hình 3D thân bán trong suốt; phần cánh ngoài thân màu xanh, phần cánh nằm trong thân màu đỏ.

Các hình được lưu thành PNG 300 dpi trong `VI/figures/`. Hình máy bay đặt cánh dịch dọc trục `x` một khoảng `0.35L` để nhìn rõ chỗ ghép; việc dịch này chỉ để vẽ, không thay đổi các kết quả tích phân của Step 2 và Step 4. Hình chưa có đuôi ngang, đuôi đứng hay các chi tiết kỹ thuật khác.

Ở hình cánh riêng, trục `z` được phóng to khi hiển thị để dễ thấy độ dày; số tọa độ vẫn tính bằng mét. Hình ghép dùng tỉ lệ các trục theo kích thước mô hình.

Hình mặt cắt giao nhau chọn một vị trí `x` đi qua thân giữa và cánh. Mặt cắt thân là đường tròn `y²+z²=r(x)²`; độ cao mặt trên/dưới của cánh tại cùng `x` lấy từ Step 1. Vùng tô đỏ là phần chung của đường tròn và dải cánh. Hình này giúp thấy rõ việc cánh xuyên qua thân trong mô hình hiện tại; không sửa hình học hoặc diện tích đã tính.

Hình 3D kiểm tra từng ô trên cánh bằng điều kiện `y²+z² ≤ r(x)²` ở đúng vị trí của thân. Các ô thỏa điều kiện được tô đỏ và thân được vẽ bán trong suốt để thấy phần cánh nằm bên trong. Đây là cách hiển thị quan hệ giữa hai mô hình, không phải phép cắt hay ghép vật thể thật.

Tham số mẫu giống các step trước: cánh `b=10 m`, dây cung gốc `1.8 m`, mút `0.9 m`; thân dài `8 m`, bán kính lớn nhất `0.7 m`, mũi `1.5 m`, đuôi `2.5 m`. Các số này lấy từ `params.yaml` của bài mẫu.

**File mã:** [step5_visualization.py](../code/step5_visualization.py).
