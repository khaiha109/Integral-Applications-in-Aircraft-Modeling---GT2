# Step 0 — Mặt cắt NACA 2412

## Vì sao làm step này?

Cánh 3D ở Step 1 cần biết mặt cắt cánh có hình gì. NACA 2412 cho một quy tắc toán học để tính mép trên và mép dưới tại từng vị trí dọc dây cung; Step 1 sẽ lấy các độ cao này và nhân với dây cung thực tế ở từng vị trí theo sải.

## Đầu vào và đầu ra

- Đầu vào: `x` là vị trí dọc dây cung đã chuẩn hóa, từ `0` (mép trước) đến `1` (mép sau).
- Đầu ra: `(upper, lower)` là độ cao mặt trên/dưới chia cho dây cung, chưa có đơn vị mét.
- Các số `m=0.02`, `p=0.4`, `t=0.12` được đọc từ mã NACA `2412`.

## Cách tính và kiểm tra

Đường camber `y_c(x)` cho độ cong giữa hai mặt. Nửa độ dày `y_t(x)` cho khoảng cách từ camber đến mỗi mặt. Mã tính `upper = y_c + y_t`, `lower = y_c - y_t`.

Kiểm tra tối thiểu: tại `x=0`, hai mặt gặp nhau; tại `x=0.4`, trung điểm của hai mặt bằng `0.02`. Độ dày cực đại xấp xỉ `0.12` lần dây cung. Công thức và phép đặt độ dày theo phương đứng được ghi trong tài liệu giả thiết của bài mẫu.

**File mã:** [step0_naca2412.py](../code/step0_naca2412.py). **Step tiếp theo:** tạo cánh 3D từ mặt cắt này.
