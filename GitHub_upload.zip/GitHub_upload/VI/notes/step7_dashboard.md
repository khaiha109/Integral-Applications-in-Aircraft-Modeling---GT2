# Step 7 — Dashboard thay đổi thông số

## Bố cục kiểm chứng hiện tại

Tab Kiểm chứng chia rõ **Phần Vĩ — Cánh và thân** và **Phần Khải — Khí động**. Không có điểm tổng kiểu `7/7 đạt` hay `14/14 đạt`. Mỗi dòng cho thấy giá trị tính được, giá trị đối chiếu và kết quả so sánh; phần khí động dùng cánh phẳng tham chiếu, còn lực trên đầu trang dùng cánh NACA. Điều kiện `L ≥ m_vỏ g` được trình bày riêng bằng số, không dùng để kết luận cả máy bay bay được.

## Vì sao làm step này?

Step 0–6 tính kết quả cho một bộ tham số. Dashboard cho phép đổi kích thước cánh và thân trên màn hình để xem diện tích, thể tích, khối lượng, lực khí động và hình 3D thay đổi ra sao.

## Luồng tính

- Thanh bên nhập sải cánh, dây cung gốc/mút, chiều dài thân, bán kính thân và độ mịn lưới.
- Step 2 tính diện tích cánh; Step 4 tính thể tích và khối lượng vỏ. Step 6 nối hình học cánh với hàm lực của Khải.
- Hình 3D lấy tọa độ từ Step 1 và Step 3. Cánh ngoài thân có màu xanh, phần nằm trong thân có màu đỏ; thân được vẽ bán trong suốt để thấy vùng giao.
- Tab **Kiểm chứng** đối chiếu `S` với công thức hình thang, `A` với cận dưới `2S` và lưới thô, thể tích thân đặc/vỏ với cách tính thứ hai, và diện tích/lực từ phần khí động. Mỗi dòng hiện giá trị và kết quả so sánh theo bộ thông số đang chọn.
- Cùng tab này hiển thị riêng bộ **14 kiểm chứng khí động của Khải** từ `src.validate.validate_aerodynamics()`. Bộ đó dùng cánh phẳng tham chiếu của Khải; số lực nâng/cản ở phần Tổng quan vẫn được tính với cánh NACA 2412 của VI.

Dashboard đọc giá trị mặc định từ `params.yaml` của bài mẫu rồi chỉ thay đổi chúng **trong bộ nhớ**. Kéo thanh điều chỉnh không sửa file tham số, code hay các ảnh PNG của Step 5. Hình ghép vẫn là mô hình minh họa, chưa cắt bỏ phần cánh nằm trong thân.

Các kết quả so sánh xác nhận phép tính nhất quán với công thức và kiểm tra số; chúng không chứng minh máy bay thật sẽ bay được. Điều kiện `A > 2S` chỉ là kiểm tra cận dưới, vì `2S` không phải diện tích bề mặt chính xác.

Dashboard còn so lực nâng ước lượng với **trọng lượng riêng vỏ thân**: `L ≥ m_vỏ × 9.81`. Đây là điều kiện tối thiểu. Nếu không thỏa, lực nâng chưa đủ nâng cả vỏ thân; nếu thỏa, vẫn chưa thể kết luận máy bay bay được vì chưa tính khối lượng cánh, động cơ, nhiên liệu và người. Mô hình khí động hiện còn tính cả đoạn cánh nằm trong thân.

Ví dụ `b=6 m`, `L_thân=16 m`, `R=1.5 m` với dây cung mặc định: lực nâng khoảng `8241 N`, khối lượng vỏ khoảng `1083.20 kg`, nên trọng lượng vỏ khoảng `10626 N` và điều kiện trên không đạt. Việc đổi kích thước thân không đổi công thức lực của phần khí động, nhưng làm khối lượng vỏ thay đổi.
Dashboard đã được kiểm tra với đúng bộ thông số này: bảng lực nâng so với vỏ cho thấy `L` nhỏ hơn `m_vỏ g` và có cảnh báo tương ứng.

Kiểm tra giao diện: với tham số gốc, `S=13.50 m²`, `A≈27.56 m²`, thân đặc `8.755 m³`, vỏ `220.45 kg`. Khi tăng sải cánh từ `10` lên `12 m`, `S` đổi thành `16.20 m²`; thân giữ nguyên thì thể tích và khối lượng vỏ không đổi.
Khi tăng bán kính thân từ `0.7` lên `1.0 m`, thể tích thân đặc đổi từ `8.755` lên `17.868 m³` và khối lượng vỏ từ `220.45` lên `315.19 kg`.

Hai bảng kiểm chứng được hiển thị đầy đủ theo phần Vĩ và phần Khải. Không cộng các hàng thành một kết luận chung cho máy bay.

**File mã:** [step7_dashboard.py](../code/step7_dashboard.py). Chạy từ `D:\HOC\GT2` bằng môi trường `.venv` của dự án:

```powershell
& '.\Integral-Applications-in-Aircraft-Modeling---GT2-main\Integral-Applications-in-Aircraft-Modeling---GT2-main\.venv\Scripts\python.exe' -m streamlit run VI\code\step7_dashboard.py
```
