# Step 3 — Hình học thân máy bay

## Vì sao làm step này?

Step 0–2 mô tả cánh. Để tính thể tích, khối lượng và vẽ thân ở các step sau, trước tiên cần biết bán kính thân tại từng vị trí từ mũi đến đuôi.

## Mô hình và đầu vào

Thân được xem là vật tròn xoay quanh trục `x`. Các tham số lấy từ `params.yaml` của bài mẫu: chiều dài `L=8 m`, bán kính lớn nhất `R=0.7 m`, mũi dài `N=1.5 m`, đuôi dài `T=2.5 m`. Đây là kích thước mô hình được chọn, không liên quan đến mã NACA 2412.

- Mũi `0 ≤ x < N`: `r(x) = R sin(πx/(2N))`, bán kính tăng từ 0 lên `R`.
- Giữa `N ≤ x ≤ L−T`: `r(x) = R`.
- Đuôi `L−T < x ≤ L`: `r(x) = R[1+cos(π(x−(L−T))/T)]/2`, bán kính giảm về 0.

Điểm trên mặt thân ở góc `θ` (radian) có tọa độ `(x, r(x)cosθ, r(x)sinθ)` tính bằng mét. Ở đây `y` là chiều ngang và `z` là chiều cao.

## Kết quả cần kiểm tra

`r(0)=0`, `r(1.5)=0.7 m`, `r(5.5)=0.7 m`, `r(8)=0`. Step 3 chỉ dựng hình học; Step 4 mới tính tích phân thể tích và khối lượng.

**File mã:** [step3_fuselage_geometry.py](../code/step3_fuselage_geometry.py).
