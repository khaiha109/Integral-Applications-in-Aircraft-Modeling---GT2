# Step 1 — Hình học cánh 3D

## Vì sao làm step này?

Step 0 chỉ mô tả một mặt cắt cánh có dây cung chuẩn hóa bằng 1. Máy bay cần cánh trải theo sải: dây cung dài ở gốc và ngắn dần ở mút. Vì vậy Step 1 biến độ cao chuẩn hóa của NACA 2412 thành tọa độ thật `(x, y, z)` tính bằng mét. Step 2 sẽ dùng mặt này để tích phân diện tích; Step 5 lấy nhiều điểm để vẽ 3D.

## Đầu vào và đầu ra

- `u`: vị trí theo dây cung, từ 0 đến 1; `y`: vị trí theo sải, từ `-b/2` đến `b/2` mét.
- `b`, `c_root`, `c_tip`: sải cánh, dây cung gốc và mút, đều tính bằng mét.
- `side`: mặt trên (`upper`) hoặc mặt dưới (`lower`).
- Đầu ra: `(x, y, z)` của một điểm trên cánh, đơn vị mét.

## Quan hệ với Step 0

Tại vị trí `y`, dây cung là `c(y) = c_root - (c_root - c_tip)|y|/(b/2)`. Gọi Step 0 tại `u` để lấy độ cao chuẩn hóa `h(u)`, rồi đổi sang mét: `x = u·c(y)`, `z = h(u)·c(y)`.

Các số `b=10`, `c_root=1.8`, `c_tip=0.9` là tham số ví dụ lấy từ `params.yaml` của dự án, không suy ra từ NACA 2412. `b=10` là sải toàn phần, nên cánh trải từ `y=-5` đến `y=5`. Khi đó `c(0)=1.8 m`, `c(5)=0.9 m`. Ở `u=0.4`, mặt trên tại gốc có tọa độ `(0.72, 0, 0.1404)` m. Step này chỉ tạo hình học; diện tích và lực là các step sau.

**File mã:** [step1_wing_geometry.py](../code/step1_wing_geometry.py).
