"""Dashboard thử thay đổi thông số cánh và thân máy bay."""

# AI-assisted: xem VI/notes/luong_nhiem_vu.md

from math import isfinite, pi

import numpy as np
import plotly.graph_objects as go
import streamlit as st

from step1_wing_geometry import wing_point
from step2_wing_area import projected_area, surface_area
from step3_fuselage_geometry import fuselage_point, fuselage_radius
from step4_fuselage_integrals import fuselage_volumes, shell_mass
from step6_validation import VIWing, compute_aero_forces, load_params
from src.validate import validate_aerodynamics


# Dựng mô hình 3D; tô đỏ các điểm cánh thỏa y²+z² ≤ r(x)² trong thân.
def aircraft_figure(
    span: float, root: float, tip: float, length: float,
    radius: float, nose: float, tail: float, resolution: int
) -> go.Figure:
    figure = go.Figure()
    x_values = np.linspace(0, length, 2 * resolution)
    angles = np.linspace(0, 2 * pi, resolution)
    body = np.array([
        [fuselage_point(float(x), float(theta), length, radius, nose, tail)
         for x in x_values]
        for theta in angles
    ])
    figure.add_surface(x=body[:, :, 0], y=body[:, :, 1], z=body[:, :, 2],
                       colorscale=[[0, "#d9a441"], [1, "#d9a441"]],
                       showscale=False, opacity=0.25, name="Thân")

    u_values = (1 - np.cos(np.linspace(0, pi, resolution))) / 2
    y_values = np.linspace(-span / 2, span / 2, resolution)
    for side, blue in (("upper", "#287bb5"), ("lower", "#9bc4d9")):
        wing = np.array([
            [wing_point(float(u), float(y), span, root, tip, side) for u in u_values]
            for y in y_values
        ])
        x = wing[:, :, 0] + 0.35 * length
        y = wing[:, :, 1]
        z = wing[:, :, 2]
        body_r = np.array([
            [fuselage_radius(float(value), length, radius, nose, tail)
             if 0 <= value <= length else 0.0 for value in row]
            for row in x
        ])
        inside = (y**2 + z**2 <= body_r**2).astype(float)
        figure.add_surface(
            x=x, y=y, z=z, surfacecolor=inside, cmin=0, cmax=1,
            colorscale=[[0, blue], [0.49, blue], [0.5, "#c43c57"],
                        [1, "#c43c57"]], showscale=False, name=f"Cánh {side}"
        )

    figure.update_layout(
        title="Cánh và thân — vùng đỏ nằm trong thân",
        scene=dict(xaxis_title="x (m)", yaxis_title="y (m)",
                   zaxis_title="z (m)", aspectmode="data",
                   camera=dict(eye=dict(x=1.5, y=1.7, z=0.9))),
        margin=dict(l=0, r=0, t=45, b=0),
    )
    return figure


# Đối chiếu các kết quả đang hiển thị với công thức, lưới thô và phần khí động.
def validation_rows(p, projected: float, area: float, volumes: dict,
                    aero, resolution: int) -> list[dict[str, str]]:
    w = p.wing
    formula = w.span * (w.chord_root + w.chord_tip) / 2
    coarse = sum(surface_area(w.span, w.chord_root, w.chord_tip,
                              resolution, max(10, resolution // 2)).values())
    checks = [
        ("S = b(c_gốc + c_mút)/2", f"{projected:.4f} m²", f"{formula:.4f} m²",
         abs(projected - formula) < 1e-6),
        ("A > 2S", f"{area:.4f} m²", f"> {2 * projected:.4f} m²",
         area > 2 * projected),
        ("A ổn định khi tăng lưới", f"{area:.4f} m²", f"Lưới thô: {coarse:.4f} m²",
         abs(area - coarse) / area < 0.001),
        ("V thân đặc ≈ công thức", f"{volumes['solid']:.5f} m³",
         f"{volumes['solid_formula']:.5f} m³",
         abs(volumes["solid"] - volumes["solid_formula"]) < 1e-5),
        ("V vỏ: Simpson ≈ hình thang", f"{volumes['skin']:.5f} m³",
         f"{volumes['skin_trapezoid']:.5f} m³",
         abs(volumes["skin"] - volumes["skin_trapezoid"]) < 1e-5),
        ("S khí động = S hình học", f"{aero.S_ref:.4f} m²", f"{projected:.4f} m²",
         abs(aero.S_ref - projected) < 1e-6),
        ("L, D hợp lệ", f"L={aero.L:.1f}, D={aero.D_total:.1f} N",
         "L > 0, D > 0", isfinite(aero.L) and isfinite(aero.D_total)
         and aero.L > 0 and aero.D_total > 0),
    ]
    return [
        {"Điều kiện": name, "Tính được": value, "Đối chiếu": reference,
         "So sánh": "Khớp" if passed else "Chưa khớp"}
        for name, value, reference, passed in checks
    ]


# So lực nâng với trọng lượng vỏ thân: W = m_vỏ × 9.81.
def shell_lift_check(lift: float, mass: float) -> dict[str, str]:
    weight = mass * 9.81
    return {
        "Điều kiện": "L ≥ m_vỏ g",
        "Tính được": f"{lift:.0f} N",
        "Đối chiếu": f"{weight:.0f} N",
        "So sánh": ("L đủ nâng riêng vỏ thân" if lift >= weight
                     else "L chưa đủ nâng riêng vỏ thân"),
    }


# Đọc tham số, tính lại S, A, V, m, L, D và hiển thị mô hình khi thanh bên đổi.
def main() -> None:
    st.set_page_config(page_title="GT2 | Step 7", page_icon="✈️", layout="wide")
    p = load_params()
    st.title("Step 7 — Thử thay đổi thông số")
    st.caption("Các giá trị chỉ đổi trên màn hình; params.yaml và code Step 0–6 không bị sửa.")

    st.sidebar.header("Kích thước mô hình")
    span = st.sidebar.slider("Sải cánh b (m)", 6.0, 20.0, float(p.wing.span), 0.5)
    root = st.sidebar.number_input("Dây cung gốc (m)", 0.5, 5.0,
                                   float(p.wing.chord_root), 0.1)
    tip = st.sidebar.number_input("Dây cung mút (m)", 0.2, 5.0,
                                  float(p.wing.chord_tip), 0.1)
    length = st.sidebar.slider("Chiều dài thân (m)", 4.0, 16.0,
                               float(p.fuselage.length), 0.5)
    radius = st.sidebar.slider("Bán kính thân (m)", 0.3, 1.5,
                               float(p.fuselage.radius_max), 0.05)
    resolution = st.sidebar.slider("Độ mịn lưới", 20, 60, 40, 10)
    if tip > root:
        st.error("Dây cung mút cần nhỏ hơn hoặc bằng dây cung gốc.")
        st.stop()

    p.wing.span, p.wing.chord_root, p.wing.chord_tip = span, root, tip
    p.fuselage.length, p.fuselage.radius_max = length, radius
    projected, _ = projected_area(span, root, tip)
    area = sum(surface_area(span, root, tip, 2 * resolution, resolution).values())
    f = p.fuselage
    volumes = fuselage_volumes(length, radius, f.nose_length,
                               f.tail_length, f.skin_thickness)
    mass = shell_mass(volumes["skin"], f.density)
    aero = compute_aero_forces(VIWing(span, root, tip), p)
    lift_check = shell_lift_check(aero.L, mass)

    first = st.columns(3)
    first[0].metric("Diện tích hình chiếu S", f"{projected:.2f} m²")
    first[1].metric("Diện tích hai mặt A", f"{area:.2f} m²")
    first[2].metric("Thể tích thân đặc", f"{volumes['solid']:.3f} m³")
    second = st.columns(3)
    second[0].metric("Khối lượng vỏ", f"{mass:.2f} kg")
    second[1].metric("Lực nâng ước lượng", f"{aero.L:.0f} N")
    second[2].metric("Lực cản ước lượng", f"{aero.D_total:.0f} N")
    if aero.L < mass * 9.81:
        st.warning(f"Lực nâng {aero.L:.0f} N nhỏ hơn trọng lượng vỏ thân "
                   f"{mass * 9.81:.0f} N.")

    model_tab, checks_tab = st.tabs(["Mô hình 3D", "Kiểm chứng"])
    with model_tab:
        st.plotly_chart(aircraft_figure(span, root, tip, length, radius,
                                        f.nose_length, f.tail_length, resolution),
                        width="stretch")
        st.caption("Màu đỏ: phần cánh nằm trong thân. Mô hình minh họa chưa cắt phần giao này.")
    with checks_tab:
        rows = validation_rows(p, projected, area, volumes, aero, resolution)
        aero_reference = validate_aerodynamics(p)
        st.subheader("Phần Vĩ — Cánh và thân")
        st.dataframe(rows, hide_index=True, width="stretch")
        st.subheader("Lực nâng so với trọng lượng vỏ thân")
        st.dataframe([lift_check], hide_index=True, width="stretch")
        st.subheader("Phần Khải — Khí động")
        st.caption("Bảng này dùng cánh phẳng tham chiếu; lực nâng và lực cản ở trên dùng cánh NACA.")
        aero_display = aero_reference[["Hạng mục", "Đại lượng", "Tích phân số",
                                       "Tham chiếu", "Sai số tương đối (%)",
                                       "Đánh giá", "Ghi chú"]].copy()
        aero_display["Tham chiếu"] = aero_display["Tham chiếu"].astype(str)
        aero_display["Đánh giá"] = aero_display["Đánh giá"].replace({
            "ĐẠT": "Khớp", "KHÔNG ĐẠT": "Chưa khớp",
            "NGOÀI KHOẢNG": "Ngoài khoảng", "CHÚ Ý": "Cần xem lại",
        })
        aero_display = aero_display.rename(columns={"Đánh giá": "So sánh"})
        st.dataframe(aero_display, hide_index=True, width="stretch")


if __name__ == "__main__":
    main()
