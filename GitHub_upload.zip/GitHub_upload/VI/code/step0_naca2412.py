"""Biên dạng cánh NACA 2412, tọa độ chuẩn hóa theo dây cung."""



from math import sqrt


# Tính mặt trên/dưới của NACA 2412: z = đường cong giữa ± nửa độ dày.
def naca2412(x: float) -> tuple[float, float]:
    """Trả về độ cao mặt trên và mặt dưới tại x/c trong [0, 1]."""
    if not 0 <= x <= 1:
        raise ValueError("x phải nằm trong [0, 1]")
    if x == 0 or x == 1:
        return 0.0, 0.0

    m, p, t = 0.02, 0.4, 0.12
    half_thickness = 5 * t * (
        0.2969 * sqrt(x) - 0.1260 * x - 0.3516 * x**2
        + 0.2843 * x**3 - 0.1036 * x**4
    )

    if x < p:
        camber = m / p**2 * (2 * p * x - x**2)
    else:
        camber = m / (1 - p)**2 * (1 - 2 * p + 2 * p * x - x**2)

    return camber + half_thickness, camber - half_thickness


if __name__ == "__main__":
    for x in (0.0, 0.4, 1.0):
        upper, lower = naca2412(x)
        print(f"x/c={x:.1f}: upper={upper:.5f}, lower={lower:.5f}")
