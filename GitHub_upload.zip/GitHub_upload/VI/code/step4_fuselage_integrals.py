"""Thể tích thân đặc, vỏ và khối lượng vật liệu."""



from math import pi
from typing import Callable

from step3_fuselage_geometry import fuselage_radius


# Xấp xỉ tích phân trên [a, b] bằng quy tắc Simpson với n khoảng chẵn.
def _simpson(function: Callable[[float], float], a: float, b: float, n: int) -> float:
    if n < 2 or n % 2:
        raise ValueError("n phải là số chẵn và ít nhất bằng 2")
    if a == b:
        return 0.0

    dx = (b - a) / n
    total = function(a) + function(b)
    for i in range(1, n):
        total += (4 if i % 2 else 2) * function(a + i * dx)
    return total * dx / 3


# Tính cùng tích phân bằng hình thang để đối chiếu kết quả Simpson.
def _trapezoid(function: Callable[[float], float], a: float, b: float, n: int) -> float:
    if n < 1:
        raise ValueError("n phải dương")
    if a == b:
        return 0.0

    dx = (b - a) / n
    total = (function(a) + function(b)) / 2
    for i in range(1, n):
        total += function(a + i * dx)
    return total * dx


# Tích phân πr² cho thân đặc và π[r²-(r-t)²] cho vỏ; đối chiếu công thức đóng.
def fuselage_volumes(
    length: float, radius_max: float, nose_length: float,
    tail_length: float, skin_thickness: float, n: int = 400
) -> dict[str, float]:
    fuselage_radius(0, length, radius_max, nose_length, tail_length)
    if not 0 <= skin_thickness < radius_max:
        raise ValueError("Bề dày vỏ phải từ 0 đến nhỏ hơn bán kính lớn nhất")

    # Diện tích mặt cắt thân đặc: A(x) = πr(x)².
    def solid_section(x: float) -> float:
        radius = fuselage_radius(x, length, radius_max, nose_length, tail_length)
        return pi * radius**2

    # Diện tích mặt cắt vỏ: A(x) = π[r(x)²-r_trong(x)²].
    def skin_section(x: float) -> float:
        radius = fuselage_radius(x, length, radius_max, nose_length, tail_length)
        inner = max(radius - skin_thickness, 0.0)
        return pi * (radius**2 - inner**2)

    bounds = (0.0, nose_length, length - tail_length, length)
    solid = 0.0
    skin = 0.0
    skin_trapezoid = 0.0
    for a, b in zip(bounds[:-1], bounds[1:]):
        solid += _simpson(solid_section, a, b, n)
        skin += _simpson(skin_section, a, b, n)
        skin_trapezoid += _trapezoid(skin_section, a, b, n)

    formula = pi * radius_max**2 * (
        nose_length / 2 + length - nose_length - tail_length + 3 * tail_length / 8
    )
    return {"solid": solid, "solid_formula": formula,
            "skin": skin, "skin_trapezoid": skin_trapezoid}


# Đổi thể tích vỏ sang khối lượng: m = ρV.
def shell_mass(skin_volume: float, density: float) -> float:
    if skin_volume < 0 or density <= 0:
        raise ValueError("Thể tích không âm và khối lượng riêng phải dương")
    return density * skin_volume


if __name__ == "__main__":
    volumes = fuselage_volumes(8.0, 0.7, 1.5, 2.5, 0.003)
    print(f"Solid volume: {volumes['solid']:.5f} m3")
    print(f"Formula check: {volumes['solid_formula']:.5f} m3")
    print(f"Shell volume: {volumes['skin']:.5f} m3")
    print(f"Trapezoid check: {volumes['skin_trapezoid']:.5f} m3")
    print(f"Shell mass: {shell_mass(volumes['skin'], 2700):.2f} kg")
