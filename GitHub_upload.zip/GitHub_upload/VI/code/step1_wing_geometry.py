"""Hình học cánh hình thang dùng mặt cắt NACA 2412."""



from step0_naca2412 import naca2412


# Dây cung tại y của cánh hình thang: c(y) = c_gốc - (c_gốc - c_mút)|y|/(b/2).
def chord_at(y: float, span: float, chord_root: float, chord_tip: float) -> float:
    if span <= 0 or chord_root <= 0 or chord_tip <= 0:
        raise ValueError("Kích thước cánh phải dương")
    if abs(y) > span / 2:
        raise ValueError("y nằm ngoài sải cánh")
    return chord_root - (chord_root - chord_tip) * abs(y) / (span / 2)


# Đổi mặt cắt Step 0 sang tọa độ thật: x = u*c(y), z = h(u)*c(y).
def wing_point(
    u: float, y: float, span: float, chord_root: float,
    chord_tip: float, side: str = "upper"
) -> tuple[float, float, float]:
    if side not in ("upper", "lower"):
        raise ValueError("side phải là upper hoặc lower")

    chord = chord_at(y, span, chord_root, chord_tip)
    upper, lower = naca2412(u)
    height = upper if side == "upper" else lower
    return u * chord, y, height * chord


if __name__ == "__main__":
    span, root, tip = 10.0, 1.8, 0.9
    for y in (0.0, span / 2):
        print(f"y={y:g} m: chord={chord_at(y, span, root, tip):.3f} m")
        print("  upper at u=0.4:", wing_point(0.4, y, span, root, tip))
