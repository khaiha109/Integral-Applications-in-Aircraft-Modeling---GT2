"""Hình học thân máy bay tròn xoay."""



from math import cos, pi, sin


# Bán kính theo vị trí x: mũi sin, thân giữa không đổi, đuôi cosine.
def fuselage_radius(
    x: float, length: float, radius_max: float,
    nose_length: float, tail_length: float
) -> float:
    if length <= 0 or radius_max <= 0:
        raise ValueError("Chiều dài và bán kính thân phải dương")
    if nose_length < 0 or tail_length < 0 or nose_length + tail_length > length:
        raise ValueError("Chiều dài mũi và đuôi không hợp lệ")
    if not 0 <= x <= length:
        raise ValueError("x nằm ngoài chiều dài thân")

    if x < nose_length:
        return radius_max * sin(pi * x / (2 * nose_length))
    if x <= length - tail_length:
        return radius_max
    return radius_max * (1 + cos(pi * (x - length + tail_length) / tail_length)) / 2


# Xoay bán kính quanh trục x: (x, y, z) = (x, r cosθ, r sinθ).
def fuselage_point(
    x: float, theta: float, length: float, radius_max: float,
    nose_length: float, tail_length: float
) -> tuple[float, float, float]:
    radius = fuselage_radius(x, length, radius_max, nose_length, tail_length)
    return x, radius * cos(theta), radius * sin(theta)


if __name__ == "__main__":
    length, radius, nose, tail = 8.0, 0.7, 1.5, 2.5
    for x in (0.0, nose, length - tail, length):
        print(f"x={x:g} m: radius={fuselage_radius(x, length, radius, nose, tail):.3f} m")
    print("Point at x=1.5 m, theta=0:", fuselage_point(nose, 0, length, radius, nose, tail))
