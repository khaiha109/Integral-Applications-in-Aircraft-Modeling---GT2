"""Xuất hình mặt cắt, cánh, thân và mô hình ghép."""



from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import to_rgba
from matplotlib.patches import Patch

from step0_naca2412 import naca2412
from step1_wing_geometry import chord_at, wing_point
from step3_fuselage_geometry import fuselage_point, fuselage_radius


# Vẽ độ cao mặt trên và dưới của mặt cắt NACA 2412 theo x/c.
def plot_airfoil(path: Path) -> None:
    u = np.linspace(0, 1, 201)
    heights = np.array([naca2412(float(value)) for value in u])
    fig, ax = plt.subplots(figsize=(9, 3.5))
    ax.plot(u, heights[:, 0], color="#287bb5", label="Upper")
    ax.plot(u, heights[:, 1], color="#dc8a35", label="Lower")
    ax.fill_between(u, heights[:, 0], heights[:, 1], color="#b8d9ec", alpha=0.5)
    ax.set(title="NACA 2412 profile", xlabel="x/c", ylabel="z/c")
    ax.set_aspect("equal", adjustable="box")
    ax.grid(alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


# Lấy lưới tọa độ trên một mặt cánh từ Step 1.
def _wing_points(span: float, root: float, tip: float, side: str) -> np.ndarray:
    u_values = (1 - np.cos(np.linspace(0, np.pi, 81))) / 2
    y_values = np.linspace(-span / 2, span / 2, 51)
    return np.array([
        [wing_point(float(u), float(y), span, root, tip, side) for u in u_values]
        for y in y_values
    ])


# Lấy lưới điểm từ Step 1 rồi vẽ cả mặt trên và mặt dưới của cánh.
def _draw_wing(ax, span: float, root: float, tip: float, x_offset: float = 0) -> None:
    for side, color in (("upper", "#287bb5"), ("lower", "#9bc4d9")):
        points = _wing_points(span, root, tip, side)
        ax.plot_surface(points[:, :, 0] + x_offset, points[:, :, 1], points[:, :, 2],
                        color=color, alpha=0.9, linewidth=0)


# Xoay đường bán kính của Step 3 quanh trục x để vẽ mặt thân.
def _draw_fuselage(
    ax, length: float, radius: float, nose: float, tail: float
) -> None:
    x_values = np.linspace(0, length, 101)
    angles = np.linspace(0, 2 * np.pi, 49)
    points = np.array([
        [fuselage_point(float(x), float(theta), length, radius, nose, tail)
         for x in x_values]
        for theta in angles
    ])
    ax.plot_surface(points[:, :, 0], points[:, :, 1], points[:, :, 2],
                    color="#d9a441", alpha=0.9, linewidth=0)


# Lưu hình 3D của riêng cánh; trục z được phóng to để thấy mặt cánh.
def plot_wing(path: Path, span: float, root: float, tip: float) -> None:
    fig = plt.figure(figsize=(9, 6))
    ax = fig.add_subplot(111, projection="3d")
    _draw_wing(ax, span, root, tip)
    ax.set(title="Wing surfaces (z enlarged)", xlabel="x (m)", ylabel="y (m)", zlabel="z (m)")
    ax.set_box_aspect((root, span, 1.2))
    ax.set_xticks([0, root / 2, root])
    ax.set_yticks([-span / 2, 0, span / 2])
    ax.set_zticks([-0.1, 0, 0.1])
    ax.view_init(elev=28, azim=-58)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


# Lưu hình 3D của riêng thân với ba đoạn mũi, giữa và đuôi.
def plot_fuselage(path: Path, length: float, radius: float, nose: float, tail: float) -> None:
    fig = plt.figure(figsize=(9, 6))
    ax = fig.add_subplot(111, projection="3d")
    _draw_fuselage(ax, length, radius, nose, tail)
    ax.set(title="Fuselage", xlabel="x (m)", ylabel="y (m)", zlabel="z (m)")
    ax.set_box_aspect((length, 2 * radius, 2 * radius))
    ax.set_xticks([0, length / 2, length])
    ax.set_yticks([-radius, 0, radius])
    ax.set_zticks([-radius, 0, radius])
    ax.xaxis.labelpad = 20
    ax.view_init(elev=23, azim=-60)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


# Ghép cánh và thân trên cùng hệ trục; vị trí cánh chỉ dùng để minh họa.
def plot_aircraft(
    path: Path, span: float, root: float, tip: float,
    length: float, radius: float, nose: float, tail: float
) -> None:
    fig = plt.figure(figsize=(10, 7))
    ax = fig.add_subplot(111, projection="3d")
    _draw_fuselage(ax, length, radius, nose, tail)
    _draw_wing(ax, span, root, tip, x_offset=0.35 * length)
    ax.set(title="Aircraft geometry (illustration)", xlabel="x (m)",
           ylabel="y (m)", zlabel="z (m)")
    ax.set_box_aspect((length, span, 2 * radius))
    ax.set_xticks([0, length / 2, length])
    ax.set_yticks([-span / 2, 0, span / 2])
    ax.set_zticks([-radius, 0, radius])
    ax.view_init(elev=27, azim=-55)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


# Vẽ mặt cắt y-z tại cùng x; tô phần chung của thân tròn và dải cánh.
def plot_wing_fuselage_intersection(
    path: Path, span: float, root: float, tip: float,
    length: float, radius: float, nose: float, tail: float
) -> None:
    wing_x = 0.4 * min(root, tip)
    body_x = 0.35 * length + wing_x
    body_radius = fuselage_radius(body_x, length, radius, nose, tail)
    y = np.linspace(-span / 2, span / 2, 1001)
    upper = np.array([
        wing_point(wing_x / chord_at(float(value), span, root, tip),
                   float(value), span, root, tip, "upper")[2]
        for value in y
    ])
    lower = np.array([
        wing_point(wing_x / chord_at(float(value), span, root, tip),
                   float(value), span, root, tip, "lower")[2]
        for value in y
    ])
    body_y = np.linspace(-body_radius, body_radius, 401)
    body_z = np.sqrt(np.maximum(body_radius**2 - body_y**2, 0))
    overlap_top = np.minimum(np.interp(body_y, y, upper), body_z)
    overlap_bottom = np.maximum(np.interp(body_y, y, lower), -body_z)

    fig, ax = plt.subplots(figsize=(8, 6))
    ax.fill_between(body_y, -body_z, body_z, color="#d9a441", alpha=0.45,
                    label="Fuselage section")
    ax.fill_between(y, lower, upper, color="#287bb5", alpha=0.75,
                    label="Wing section")
    ax.fill_between(body_y, overlap_bottom, overlap_top,
                    where=overlap_top > overlap_bottom, color="#c43c57",
                    alpha=0.95, label="Wing inside fuselage")
    ax.plot(body_y, body_z, color="#9b6a20", linewidth=1.5)
    ax.plot(body_y, -body_z, color="#9b6a20", linewidth=1.5)
    ax.axhline(0, color="#555555", linestyle="--", linewidth=0.8)
    ax.set(xlim=(-1.1, 1.1), ylim=(-0.85, 0.85),
           title=f"Front section at x = {body_x:.2f} m",
           xlabel="span y (m)", ylabel="height z (m)")
    ax.set_aspect("equal", adjustable="box")
    ax.grid(alpha=0.2)
    ax.legend(loc="upper right")
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


# Tô đỏ các ô cánh nằm trong thân và vẽ thân trong suốt để thấy chỗ xuyên qua.
def plot_aircraft_intersection_3d(
    path: Path, span: float, root: float, tip: float,
    length: float, radius: float, nose: float, tail: float
) -> None:
    fig = plt.figure(figsize=(10, 7))
    ax = fig.add_subplot(111, projection="3d")
    x_values = np.linspace(0, length, 81)
    angles = np.linspace(0, 2 * np.pi, 33)
    body = np.array([
        [fuselage_point(float(x), float(theta), length, radius, nose, tail)
         for x in x_values]
        for theta in angles
    ])
    ax.plot_surface(body[:, :, 0], body[:, :, 1], body[:, :, 2],
                    color="#d9a441", alpha=0.15, linewidth=0, shade=False)

    x_offset = 0.35 * length
    for side, color in (("upper", "#287bb5"), ("lower", "#9bc4d9")):
        points = _wing_points(span, root, tip, side)
        x = points[:, :, 0] + x_offset
        y = points[:, :, 1]
        z = points[:, :, 2]
        middle_x = (x[:-1, :-1] + x[1:, 1:]) / 2
        middle_y = (y[:-1, :-1] + y[1:, 1:]) / 2
        middle_z = (z[:-1, :-1] + z[1:, 1:]) / 2
        body_r = np.array([
            fuselage_radius(float(value), length, radius, nose, tail)
            for value in middle_x.flat
        ]).reshape(middle_x.shape)
        inside = middle_y**2 + middle_z**2 <= body_r**2
        facecolors = np.where(inside[:, :, None], to_rgba("#c43c57"), to_rgba(color))
        ax.plot_surface(x, y, z, facecolors=facecolors, shade=False,
                        rstride=1, cstride=1, linewidth=0)

    ax.plot_wireframe(body[:, :, 0], body[:, :, 1], body[:, :, 2],
                      rstride=4, cstride=8, color="#8b682c", alpha=0.45, linewidth=0.6)
    ax.set(title="Wing passing through transparent fuselage",
           xlabel="x (m)", ylabel="y (m)", zlabel="z (m)")
    ax.set_box_aspect((length, span, 2 * radius))
    ax.set_xticks([0, length / 2, length])
    ax.set_yticks([-span / 2, 0, span / 2])
    ax.set_zticks([-radius, 0, radius])
    ax.view_init(elev=22, azim=-55)
    ax.legend(handles=[Patch(color="#d9a441", alpha=0.4, label="Fuselage"),
                       Patch(color="#287bb5", label="Wing outside"),
                       Patch(color="#c43c57", label="Wing inside")],
              loc="upper right")
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


# Tạo thư mục figures và xuất sáu ảnh PNG từ tham số mẫu.
def save_figures() -> list[Path]:
    folder = Path(__file__).resolve().parents[1] / "figures"
    folder.mkdir(parents=True, exist_ok=True)
    span, root, tip = 10.0, 1.8, 0.9
    length, radius, nose, tail = 8.0, 0.7, 1.5, 2.5
    paths = [folder / name for name in (
        "airfoil_profile.png", "wing_3d.png", "fuselage_3d.png",
        "aircraft_3d.png", "wing_fuselage_intersection.png",
        "aircraft_intersection_3d.png"
    )]
    plot_airfoil(paths[0])
    plot_wing(paths[1], span, root, tip)
    plot_fuselage(paths[2], length, radius, nose, tail)
    plot_aircraft(paths[3], span, root, tip, length, radius, nose, tail)
    plot_wing_fuselage_intersection(paths[4], span, root, tip, length, radius, nose, tail)
    plot_aircraft_intersection_3d(paths[5], span, root, tip, length, radius, nose, tail)
    return paths


if __name__ == "__main__":
    for file in save_figures():
        print(file)
