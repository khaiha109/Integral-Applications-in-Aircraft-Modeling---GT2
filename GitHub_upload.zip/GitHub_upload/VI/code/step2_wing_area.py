"""Diện tích hình chiếu và bề mặt cánh NACA 2412."""



from math import cos, pi, sqrt

from step1_wing_geometry import chord_at, wing_point


# Tính diện tích hình chiếu bằng chia dải; đối chiếu S = b*(c_gốc + c_mút)/2.
def projected_area(span: float, root: float, tip: float, n_span: int = 100) -> tuple[float, float]:
    if n_span < 1:
        raise ValueError("n_span phải dương")

    dy = span / n_span
    numerical = sum(
        chord_at(-span / 2 + (j + 0.5) * dy, span, root, tip) * dy
        for j in range(n_span)
    )
    formula = span * (root + tip) / 2
    return numerical, formula


# Diện tích một tam giác trong không gian: A = |AB × AC|/2.
def _triangle_area(a, b, c):
    ab = (b[0] - a[0], b[1] - a[1], b[2] - a[2])
    ac = (c[0] - a[0], c[1] - a[1], c[2] - a[2])
    cross = (
        ab[1] * ac[2] - ab[2] * ac[1],
        ab[2] * ac[0] - ab[0] * ac[2],
        ab[0] * ac[1] - ab[1] * ac[0],
    )
    return sqrt(sum(component**2 for component in cross)) / 2


# Cộng các tam giác ở hai mặt cánh, xấp xỉ A = ∫∫|r_u × r_y| du dy.
def surface_area(
    span: float, root: float, tip: float,
    n_chord: int = 200, n_span: int = 100
) -> dict[str, float]:
    if n_chord < 2 or n_span < 1:
        raise ValueError("Lưới cần ít nhất 2 ô theo dây cung và 1 ô theo sải")

    u_values = [(1 - cos(pi * i / n_chord)) / 2 for i in range(n_chord + 1)]
    areas = {}

    for side in ("upper", "lower"):
        previous = [wing_point(u, 0, span, root, tip, side) for u in u_values]
        half_area = 0.0
        for j in range(1, n_span + 1):
            y = span * j / (2 * n_span)
            current = [wing_point(u, y, span, root, tip, side) for u in u_values]
            for i in range(n_chord):
                half_area += _triangle_area(previous[i], previous[i + 1], current[i + 1])
                half_area += _triangle_area(previous[i], current[i + 1], current[i])
            previous = current
        areas[side] = 2 * half_area

    return areas


if __name__ == "__main__":
    span, root, tip = 10.0, 1.8, 0.9
    numerical, formula = projected_area(span, root, tip)
    areas = surface_area(span, root, tip)
    print(f"Projected area: {numerical:.4f} m2 (formula: {formula:.4f} m2)")
    print(f"Upper surface: {areas['upper']:.4f} m2")
    print(f"Lower surface: {areas['lower']:.4f} m2")
    print(f"Total surface area: {sum(areas.values()):.4f} m2")
