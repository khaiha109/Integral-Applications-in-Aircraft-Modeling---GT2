"""Đối chiếu các step và nối hình học cánh với phần khí động."""



import math
import sys
from pathlib import Path

import numpy as np

from step0_naca2412 import naca2412
from step1_wing_geometry import chord_at, wing_point
from step2_wing_area import projected_area, surface_area
from step3_fuselage_geometry import fuselage_radius
from step4_fuselage_integrals import fuselage_volumes

PROJECT = Path(__file__).resolve().parents[2] / "Integral-Applications-in-Aircraft-Modeling---GT2-main"
PROJECT = PROJECT / PROJECT.name
sys.path.insert(0, str(PROJECT))

from src.aero import compute_aero_forces
from src.config import load_params


class VIWing:
    # Giữ kích thước cánh để truyền vào giao diện khí động của Khải.
    def __init__(self, span: float, root: float, tip: float) -> None:
        self.span, self.root, self.tip = span, root, tip

    # Phần khí động chỉ tích phân nửa cánh: semi_span = b/2.
    @property
    def semi_span(self) -> float:
        return self.span / 2

    # Đổi wing_point của Step 1 thành ba mảng X, Y, Z cho u, v và hai mặt cánh.
    def surface(self, u: np.ndarray, v: np.ndarray, side: int):
        if side not in (+1, -1):
            raise ValueError("side phải là +1 hoặc -1")
        u_array, v_array = np.broadcast_arrays(np.asarray(u, float), np.asarray(v, float))
        name = "upper" if side == +1 else "lower"
        points = np.array([
            wing_point(float(ui), float(vi), self.span, self.root, self.tip, name)
            for ui, vi in zip(u_array.flat, v_array.flat)
        ]).reshape(u_array.shape + (3,))
        return points[..., 0], points[..., 1], points[..., 2]


# So Step 0–5 với công thức, mốc hình học, hội tụ lưới và file hình.
def geometry_checks(p) -> tuple[dict[str, bool], float]:
    w, f = p.wing, p.fuselage
    upper, lower = naca2412(0.4)
    s_numeric, s_formula = projected_area(w.span, w.chord_root, w.chord_tip)
    area_coarse = sum(surface_area(w.span, w.chord_root, w.chord_tip, 80, 40).values())
    area_fine = sum(surface_area(w.span, w.chord_root, w.chord_tip, 160, 80).values())
    volumes = fuselage_volumes(f.length, f.radius_max, f.nose_length,
                               f.tail_length, f.skin_thickness)
    radius_args = (f.length, f.radius_max, f.nose_length, f.tail_length)
    folder = Path(__file__).resolve().parents[1] / "figures"
    figure_names = (
        "airfoil_profile.png", "wing_3d.png", "fuselage_3d.png",
        "aircraft_3d.png", "wing_fuselage_intersection.png",
        "aircraft_intersection_3d.png"
    )

    checks = {
        "Step 0: NACA camber": abs((upper + lower) / 2 - 0.02) < 1e-12,
        "Step 1: root and tip chord": (
            abs(chord_at(0, w.span, w.chord_root, w.chord_tip) - w.chord_root) < 1e-12
            and abs(chord_at(w.span / 2, w.span, w.chord_root, w.chord_tip)
                    - w.chord_tip) < 1e-12
        ),
        "Step 2: projected area": abs(s_numeric - s_formula) < 1e-8,
        "Step 2: surface mesh": abs(area_coarse - area_fine) < 0.005
                                and area_fine > 2 * s_formula,
        "Step 3: fuselage radius": (
            abs(fuselage_radius(0, *radius_args)) < 1e-12
            and abs(fuselage_radius(f.nose_length, *radius_args) - f.radius_max) < 1e-12
            and abs(fuselage_radius(f.length - f.tail_length, *radius_args)
                    - f.radius_max) < 1e-12
            and abs(fuselage_radius(f.length, *radius_args)) < 1e-12
        ),
        "Step 4: solid volume": abs(volumes["solid"] - volumes["solid_formula"]) < 1e-6,
        "Step 4: shell volume": abs(volumes["skin"] - volumes["skin_trapezoid"]) < 1e-5
                                and 0 < volumes["skin"] < volumes["solid"],
        "Step 5: figures": all((folder / name).is_file() for name in figure_names),
    }
    print(f"S={s_formula:.4f} m2, A={area_fine:.4f} m2, "
          f"V={volumes['solid']:.5f} m3, V_shell={volumes['skin']:.5f} m3")
    return checks, s_formula


# Truyền cánh VI vào aero.py rồi so S_ref với Step 2 và kiểm tra lực hữu hạn.
def aero_checks(p, expected_area: float) -> dict[str, bool]:
    wing = VIWing(p.wing.span, p.wing.chord_root, p.wing.chord_tip)
    result = compute_aero_forces(wing, p)
    print(f"Aero: L={result.L:.2f} N, D={result.D_total:.2f} N, S_ref={result.S_ref:.4f} m2")
    return {
        "Khai: reference area": abs(result.S_ref - expected_area) < 1e-6,
        "Khai: finite forces": math.isfinite(result.L) and math.isfinite(result.D_total)
                              and result.L > 0 and result.D_total > 0,
    }


# Chạy mọi phép kiểm tra và báo PASS/FAIL cho từng phần.
def main() -> int:
    p = load_params()
    if p.airfoil.naca != "2412":
        raise ValueError("Bộ step VI hiện dùng mặt cắt NACA 2412")
    checks, area = geometry_checks(p)
    checks.update(aero_checks(p, area))
    for name, passed in checks.items():
        print(f"{'PASS' if passed else 'FAIL'}  {name}")
    return 0 if all(checks.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
