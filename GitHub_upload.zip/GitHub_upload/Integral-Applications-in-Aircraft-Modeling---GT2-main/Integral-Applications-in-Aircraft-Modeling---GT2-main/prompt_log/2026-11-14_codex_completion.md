# Nhật ký Prompt - Ngày 14/11/2026: Hoàn thiện dự án GT2

- **Công cụ AI:** Codex (GPT-6)
- **Người yêu cầu:** người dùng dự án GT2
- **Phạm vi:** hình học của Trương Thanh Vĩ, pipeline, dashboard, kiểm thử và tài liệu; giữ nguyên mô hình khí động của Hà Ngọc Khải.

## Prompt gốc của người dùng

```text# VAI TRÒ VÀ MỤC TIÊU

Bạn là một kỹ sư phần mềm Python, chuyên gia tính toán khoa học và trợ lý hướng dẫn lập trình.

Tôi là người mới hoàn toàn với Python. Tôi muốn bạn tự động hóa quá trình hoàn thiện bài tập lớn GT2 – Ứng dụng tích phân trong mô hình hóa máy bay.

Bạn sẽ đảm nhận việc phân tích, viết code, chạy chương trình, kiểm thử, sửa lỗi và trực quan hóa kết quả. Tôi sẽ giám sát tiến độ và tìm hiểu các công thức toán học thông qua phần giải thích của bạn.

**Yêu cầu quan trọng nhất: Tôi phải biết bạn đang làm gì và nhìn thấy được kết quả trực quan, không chỉ nhận mã nguồn.**

## 1. PHÂN TÍCH DỰ ÁN

- Đọc toàn bộ các file README.md, PHANCONG.txt, DETAINGHIENCUU.txt, params.yaml và mã nguồn Python.
- Xác định các chức năng đã hoàn thành, chưa hoàn thành, lỗi hiện tại và quan hệ phụ thuộc giữa các module.
- Đối chiếu với yêu cầu đề tài và phân công nhóm.
- Ưu tiên hoàn thiện phần của Trương Thanh Vĩ.
- Giữ nguyên phần của Hà Ngọc Khải, ngoại trừ những chỉnh sửa tương thích thực sự cần thiết. Nếu phải chỉnh sửa, hãy giải thích và ghi lại thay đổi.

Lập kế hoạch theo từng giai đoạn rồi chủ động thực hiện. Không cần hỏi tôi trước mỗi thao tác thông thường.

## 2. TỰ ĐỘNG LẬP TRÌNH

Hoàn thiện các phần được giao:

1. airfoil.py: Xây dựng biên dạng NACA 2412.
2. wing.py: Mô hình cánh và tích phân kép tính diện tích.
3. fuselage.py: Mô hình thân và tích phân bội ba tính thể tích, khối lượng.
4. validate.py: Kiểm chứng kết quả toán học và sai số.
5. visualize.py: Vẽ đồ thị 2D và mô hình 3D.
6. main.py: Kết nối các module để chương trình chạy hoàn chỉnh.

Tự động thực hiện chu trình:

Phân tích → Viết code → Chạy thử → Phát hiện lỗi → Sửa lỗi → Kiểm chứng → Xuất kết quả.

Tự kiểm tra môi trường Python, tạo môi trường ảo nếu cần, cài các thư viện còn thiếu và giữ danh sách phụ thuộc rõ ràng.

Không tự ý thay đổi các giả thiết vật lý hoặc thông số gốc nếu không có lý do và tài liệu giải thích.

## 3. THEO DÕI CÔNG VIỆC

Tôi muốn giám sát được toàn bộ quá trình.

Tạo file PROGRESS.md trong thư mục dự án, bao gồm:

- Công việc đã hoàn thành.
- Công việc đang thực hiện.
- Công việc chưa hoàn thành.
- File đang được chỉnh sửa.
- Lỗi đã phát hiện và cách giải quyết.
- Kết quả kiểm thử mới nhất.
- Công việc tiếp theo.

Sau mỗi giai đoạn, cập nhật file này và gửi một báo cáo ngắn ngay trong cuộc trò chuyện Codex.

Mỗi báo cáo phải giải thích bằng tiếng Việt:

- Bạn vừa thực hiện công việc gì?
- Vì sao cần làm?
- Đã thay đổi những file nào?
- Kết quả chạy thử ra sao?
- Có còn lỗi nào không?

Tôi không cần xem từng dòng suy luận nội bộ, nhưng cần thông tin tiến độ và các thao tác thực tế có thể kiểm chứng.

## 4. TẠO GIAO DIỆN TRỰC QUAN

Hãy xây dựng một Dashboard bằng Streamlit kết hợp Plotly để tôi có thể mở trên trình duyệt.

Dashboard có các khu vực:

**A. Tổng quan dự án**
- Hiển thị các thông số máy bay.
- Hiển thị diện tích, thể tích và khối lượng.
- Cho biết kết quả nào đã được kiểm chứng.
- Hiển thị tiến độ các module.

**B. Mô hình cánh**
- Đồ thị biên dạng NACA 2412.
- Hình 3D của cánh máy bay.
- Cho phép xoay, phóng to và thu nhỏ.

**C. Mô hình thân**
- Đồ thị bán kính thân theo chiều dài.
- Mô hình thân máy bay 3D.
- Bảng thể tích và khối lượng.

**D. Tích phân**
- Hiển thị các công thức tích phân được sử dụng.
- Hiển thị giá trị tính được và đơn vị.
- Có đồ thị minh họa miền tích phân.
- So sánh kết quả giải tích và tính toán số.

**E. Mô hình máy bay hoàn chỉnh**
- Ghép cánh và thân thành mô hình 3D.
- Cho phép xoay 360 độ, zoom và quan sát.
- Có tùy chọn bật/tắt các thành phần và lưới.

**F. Kiểm chứng**
- Bảng sai số.
- Đồ thị hội tụ khi thay đổi độ mịn lưới.
- Trạng thái các bài kiểm thử.
- Cảnh báo nếu kết quả không hợp lý.

## 5. TƯƠNG TÁC VỚI MÔ HÌNH

Tạo thanh điều khiển để thay đổi các thông số như:

- Sải cánh.
- Dây cung gốc và đầu cánh.
- Chiều dài thân.
- Bán kính thân.
- Độ phân giải lưới.

Nếu thông số nào không được phép thay đổi theo yêu cầu đề tài, hãy giữ giá trị mặc định hoặc giải thích rõ.

Khi thay đổi thông số, Dashboard phải tính toán lại và cập nhật đồ thị.

## 6. HIỂN THỊ KẾT QUẢ KHI CHẠY

Tôi muốn quan sát kết quả thực tế sau mỗi giai đoạn.

- Chạy kiểm thử trong Terminal của VS Code.
- Hiển thị lỗi rõ ràng nếu có.
- Lưu bảng kết quả và đồ thị trong thư mục outputs/.
- Tạo các hình PNG phù hợp để đưa vào báo cáo.
- Tạo mô hình 3D HTML tương tác.
- Mở hoặc cung cấp đường dẫn tới Dashboard sau khi khởi chạy thành công.
- Nếu có thể, tự cập nhật Dashboard theo dữ liệu tiến độ và kết quả mới nhất.

Không chỉ thông báo rằng chương trình đã chạy thành công; phải cung cấp kết quả thực tế và bằng chứng kiểm thử.

## 7. GIẢI THÍCH CHO NGƯỜI CHƯA BIẾT PYTHON

Sau mỗi phần hoàn thành, giải thích ngắn gọn:

1. Công thức toán học được sử dụng.
2. Công thức đó được chuyển thành Python như thế nào.
3. Input và output của hàm.
4. Ý nghĩa của kết quả.
5. Cách kiểm tra kết quả đúng hay sai.

Dùng tiếng Việt dễ hiểu, tránh thuật ngữ lập trình phức tạp nếu không cần thiết.

## 8. NGUYÊN TẮC LÀM VIỆC

- Chủ động triển khai từ đầu đến cuối.
- Không cần hỏi tôi những quyết định kỹ thuật nhỏ.
- Không xóa dữ liệu hoặc ghi đè những phần đã hoàn thành mà chưa sao lưu.
- Không tự ý xóa hay thay đổi nội dung nhóm khác.
- Giữ cấu trúc dự án rõ ràng.
- Không bịa kết quả tính toán hoặc kết quả kiểm thử.
- Không tuyên bố hoàn thành nếu còn lỗi.
- Nếu thiếu dữ liệu quan trọng, ghi rõ giả thiết và mức độ ảnh hưởng.
- Chỉ yêu cầu tôi can thiệp khi thực sự cần quyền truy cập, xác nhận thao tác rủi ro hoặc quyết định ảnh hưởng đến yêu cầu đề tài.

## 9. ĐIỀU KIỆN HOÀN THÀNH

Chỉ đánh dấu dự án hoàn thành khi:

- Chương trình chính chạy được.
- Các phép tích phân có kết quả và kiểm chứng.
- Các bài kiểm thử cần thiết đạt.
- Dashboard mở và hoạt động được.
- Mô hình 3D hiển thị được.
- Các file ảnh và kết quả được xuất thành công.
- PROGRESS.md được cập nhật đầy đủ.
- Có hướng dẫn đơn giản để tôi tự chạy lại dự án.

Bắt đầu ngay bằng việc đọc và phân tích toàn bộ dự án, lập kế hoạch, sau đó thực hiện theo từng giai đoạn và thường xuyên cập nhật tiến độ cho tôi.
```

## Tóm tắt phản hồi và phần được dùng

- Hoàn thiện biên dạng NACA, cánh, thân và các phép tích phân; đối chiếu tích phân số với công thức đóng.
- Nối `main.py`, tạo dashboard Streamlit và xuất CSV/PNG/HTML vào `outputs/`.
- Bổ sung 11 kiểm thử có nội dung; hai test `pass` thuộc phần Khải được giữ nguyên và loại khỏi thống kê.
- Viết `docs/assumptions.md`, `README.md`, `PROGRESS.md`, khai báo AI. Nhóm cần rà soát công thức và hình trước khi nộp.