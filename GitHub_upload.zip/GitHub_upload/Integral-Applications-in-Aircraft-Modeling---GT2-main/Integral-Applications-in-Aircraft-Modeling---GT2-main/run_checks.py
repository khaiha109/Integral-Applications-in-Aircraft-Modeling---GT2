"""Chạy các kiểm thử có nội dung và ghi trạng thái cho dashboard.

Hai test `pass` của phần Khải trong test_basic.py là khung chưa triển khai;
chúng không được tính là bài kiểm thử đạt. Không sửa file của Khải.
# AI-assisted: xem AI_DECLARATION.md
"""

from __future__ import annotations

import io
import json
import sys
import unittest
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo


ROOT = Path(__file__).resolve().parent
PLACEHOLDERS = {
    "test_lift_direction_positive_alpha",
    "test_aerodynamic_force_magnitude",
}


def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item


def main() -> int:
    loader = unittest.TestLoader()
    discovered = loader.discover(str(ROOT / "tests"), pattern="test_*.py")
    tests = list(flatten(discovered))
    excluded = [test for test in tests if test._testMethodName in PLACEHOLDERS]
    selected = [test for test in tests if test._testMethodName not in PLACEHOLDERS]
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(
        unittest.TestSuite(selected))
    output = stream.getvalue()
    data = {
        "time": datetime.now(ZoneInfo("Asia/Bangkok")).isoformat(timespec="seconds"),
        "tests_run": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "excluded_placeholders": len(excluded),
        "success": result.wasSuccessful(),
        "output": output,
    }
    ROOT.joinpath("outputs").mkdir(exist_ok=True)
    (ROOT / "outputs" / "test_results.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    print(output)
    print(f"Đã bỏ qua {len(excluded)} test 'pass' của phần Khải vì chưa có nội dung kiểm tra.")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
