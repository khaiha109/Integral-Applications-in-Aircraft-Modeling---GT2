# Khai báo sử dụng AI (AI Declaration)

Theo quy định của đề tài GT2, bảng dưới đây ghi nhận các phần code do AI tạo, hỗ trợ hoặc chỉnh sửa. Các mục Codex cần được thành viên nhóm rà soát trước khi nộp.

| File | Hàm / Đoạn code | AI tạo hay sửa | Công cụ AI | Prompt log | Người rà soát |
|---|---|---|---|---|---|
| Toàn bộ các file `.py` | Khởi tạo cấu trúc file, import thư viện và TODO comments | Tạo khung | Antigravity (Gemini 3.8 Flash) | `prompt_log/2026-11-09_initial_setup.md` | Hà Ngọc Khải & Trương Thanh Vĩ |
| `params.yaml` | Thiết lập tham số mặc định từ README | Tạo | Antigravity (Gemini 3.8 Flash) | `prompt_log/2026-11-09_initial_setup.md` | Hà Ngọc Khải |
| `src/airfoil.py`, `src/wing.py`, `src/fuselage.py` | Toàn bộ hàm hình học và tích phân phần Vĩ | Viết hoàn chỉnh từ khung | Codex (GPT-6) | `prompt_log/2026-11-14_codex_completion.md` | Chờ Trương Thanh Vĩ rà soát |
| `src/validate.py` | `validate_geometry`, `check_mesh_convergence` (phần Vĩ) | Viết hoàn chỉnh từ khung | Codex (GPT-6) | `prompt_log/2026-11-14_codex_completion.md` | Chờ Trương Thanh Vĩ rà soát |
| `src/visualize.py` | Hình 2D/3D phần Vĩ và hàm dựng Plotly | Viết hoàn chỉnh từ khung | Codex (GPT-6) | `prompt_log/2026-11-14_codex_completion.md` | Chờ Trương Thanh Vĩ rà soát |
| `src/aero_plots.py` | Xuất đồ thị Cp và cực khí động qua API hiện có | Tạo mới | Codex (GPT-6) | `prompt_log/2026-11-14_codex_completion.md` | Chờ Hà Ngọc Khải rà soát |
| `main.py`, `dashboard.py`, `run_checks.py` | Pipeline, giao diện và chạy kiểm thử | Viết mới/tích hợp | Codex (GPT-6) | `prompt_log/2026-11-14_codex_completion.md` | Chờ cả nhóm rà soát |
| `tests/test_basic.py` | Chỉ các test phần Vĩ | Hoàn thiện từ `pass` | Codex (GPT-6) | `prompt_log/2026-11-14_codex_completion.md` | Chờ Trương Thanh Vĩ rà soát |
| `tests/test_integration.py` | Kiểm thử ghép module và pipeline | Tạo mới | Codex (GPT-6) | `prompt_log/2026-11-14_codex_completion.md` | Chờ cả nhóm rà soát |
| `requirements.txt`, `README.md`, `docs/assumptions.md`, `PROGRESS.md` | Phụ thuộc, hướng dẫn, giả thiết, tiến độ | Bổ sung | Codex (GPT-6) | `prompt_log/2026-11-14_codex_completion.md` | Chờ cả nhóm rà soát |
| `VI/code/step0_naca2412.py` (thư mục `GT2/VI`) | Mặt cắt NACA 2412 theo step | Tạo mẫu | Codex (GPT-6) | `prompt_log/2026-11-14_vi_steps.md` | Chờ Trương Thanh Vĩ tự rà soát |
| `VI/code/step1_wing_geometry.py` (thư mục `GT2/VI`) | Dây cung và tọa độ điểm trên cánh | Tạo mẫu | Codex (GPT-6) | `prompt_log/2026-11-14_vi_steps.md` | Chờ Trương Thanh Vĩ tự rà soát |
| `VI/code/step2_wing_area.py` (thư mục `GT2/VI`) | Diện tích hình chiếu và bề mặt cánh | Tạo mẫu | Codex (GPT-6) | `prompt_log/2026-11-14_vi_steps.md` | Chờ Trương Thanh Vĩ tự rà soát |
| `VI/code/step3_fuselage_geometry.py` (thư mục `GT2/VI`) | Bán kính và tọa độ điểm trên thân | Tạo mẫu | Codex (GPT-6) | `prompt_log/2026-11-14_vi_steps.md` | Chờ Trương Thanh Vĩ tự rà soát |
| `VI/code/step4_fuselage_integrals.py` (thư mục `GT2/VI`) | Thể tích thân đặc, thể tích và khối lượng vỏ | Tạo mẫu | Codex (GPT-6) | `prompt_log/2026-11-14_vi_steps.md` | Chờ Trương Thanh Vĩ tự rà soát |
| `VI/code/step5_visualization.py` (thư mục `GT2/VI`) | Xuất hình mặt cắt, cánh, thân và hình ghép | Tạo mẫu | Codex (GPT-6) | `prompt_log/2026-11-14_vi_steps.md` | Chờ Trương Thanh Vĩ tự rà soát |
| `VI/code/step6_validation.py` (thư mục `GT2/VI`) | Đối chiếu kết quả các step và nối với `src/aero.py` | Tạo mẫu | Codex (GPT-6) | `prompt_log/2026-11-14_vi_steps.md` | Chờ Trương Thanh Vĩ tự rà soát |
| `VI/code/step7_dashboard.py` (thư mục `GT2/VI`) | Dashboard đổi kích thước cánh/thân, số liệu và hình 3D | Tạo mẫu | Codex (GPT-6) | `prompt_log/2026-11-14_vi_steps.md` | Chờ Trương Thanh Vĩ tự rà soát |

`src/aero.py`, `src/config.py` và hai hàm kiểm chứng khí động trong `src/validate.py` không được Codex sửa trong phiên này. Hai test `pass` của Khải trong `tests/test_basic.py` được giữ nguyên và bị loại khỏi thống kê bài kiểm thử thực tế.
