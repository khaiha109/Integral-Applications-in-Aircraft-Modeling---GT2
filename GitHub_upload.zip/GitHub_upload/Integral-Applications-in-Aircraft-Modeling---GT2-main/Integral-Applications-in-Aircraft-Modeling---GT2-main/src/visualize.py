"""
Module visualize.py: Trực quan hóa hình học 3D, vẽ đồ thị phân bố áp suất và xuất kết quả.
Người phụ trách:
- Trương Thanh Vĩ: Trực quan hóa 3D (Matplotlib 3D, Plotly Interactive 3D HTML, xuất ảnh mô hình 3D)
- Hà Ngọc Khải: Biểu đồ khí động học 2D (phân bố Cp, đường đặc tuyến nâng/cản theo alpha, xuất đồ thị kết quả)
"""

from pathlib import Path
from typing import Dict, Any
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import plotly.graph_objects as go

from src.config import Params, load_params
from src.airfoil import get_airfoil_coordinates
from src.wing import wing_surface
from src.fuselage import fuselage_surface_3d, fuselage_radius


def _params(config: Params | None) -> Params:
    if config is None:
        return load_params()
    if not isinstance(config, Params):
        raise TypeError("config phải là Params từ load_params().")
    return config


def _path(save_path: Path | str | None, name: str) -> Path:
    path = Path(save_path) if save_path else Path(__file__).resolve().parents[1] / "outputs" / "figures" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


# ==============================================================================
# PHẦN VIỆC CỦA TRƯƠNG THANH VĨ (Trực quan hóa 3D)
# ==============================================================================

def plot_airfoil_2d(naca_code: str = "2412", save_path: Path | str | None = None) -> None:
    """Lưu PNG biên dạng và camber NACA, 300 dpi. # AI-assisted"""
    x = (1 - np.cos(np.linspace(0, np.pi, 401))) / 2
    xu, zu, xl, zl = get_airfoil_coordinates(x, naca_code)
    fig, ax = plt.subplots(figsize=(9, 3.5))
    ax.plot(xu, zu, label="Mặt trên", color="#146C94", linewidth=2)
    ax.plot(xl, zl, label="Mặt dưới", color="#E38B29", linewidth=2)
    ax.plot(x, (zu + zl) / 2, "--", label="Đường camber", color="#5B6470")
    ax.fill_between(x, zl, zu, color="#56B6C2", alpha=0.18)
    ax.set(title=f"Biên dạng NACA {naca_code}", xlabel="x/c", ylabel="z/c")
    ax.set_aspect("equal", adjustable="box")
    ax.grid(alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(_path(save_path, "airfoil_profile.png"), dpi=300)
    plt.close(fig)


def plot_wing_3d_matplotlib(config: Params | None = None,
                            save_path: Path | str | None = None) -> None:
    """Lưu PNG cánh 3D hai mặt, 300 dpi. # AI-assisted"""
    p = _params(config)
    u = (1 - np.cos(np.linspace(0, np.pi, min(p.wing.n_chord, 100)))) / 2
    v = np.linspace(-p.wing.semi_span, p.wing.semi_span, min(p.wing.n_span, 60))
    U, V = np.meshgrid(u, v)
    fig = plt.figure(figsize=(10, 6))
    ax = fig.add_subplot(111, projection="3d")
    for side, color in (("upper", "#2E86AB"), ("lower", "#B7DCE8")):
        X, Y, Z = wing_surface(U, V, p.wing.span, p.wing.chord_root,
                               p.wing.chord_tip, p.airfoil.naca, side)
        ax.plot_surface(X, Y, Z, color=color, alpha=0.95, linewidth=0,
                        antialiased=True)
    ax.set(xlabel="x [m]", ylabel="y [m]", zlabel="z [m]", title="Cánh NACA " + p.airfoil.naca)
    ax.set_box_aspect((p.wing.chord_root, p.wing.span, 0.8))
    ax.view_init(elev=28, azim=-57)
    fig.tight_layout()
    fig.savefig(_path(save_path, "wing_3d.png"), dpi=300)
    plt.close(fig)


def plot_fuselage_3d_matplotlib(config: Params | None = None,
                                save_path: Path | str | None = None) -> None:
    """Lưu PNG thân 3D, 300 dpi. # AI-assisted"""
    p = _params(config)
    f = p.fuselage
    X, Y, Z = fuselage_surface_3d(f.length, f.radius_max, 120, 64,
                                  f.nose_length, f.tail_length)
    fig = plt.figure(figsize=(10, 6))
    ax = fig.add_subplot(111, projection="3d")
    ax.plot_surface(X, Y, Z, color="#D9A441", alpha=0.95, linewidth=0)
    ax.set(xlabel="x [m]", ylabel="y [m]", zlabel="z [m]", title="Thân máy bay")
    ax.set_box_aspect((f.length, 2 * f.radius_max, 2 * f.radius_max))
    ax.view_init(elev=23, azim=-60)
    fig.tight_layout()
    fig.savefig(_path(save_path, "fuselage_3d.png"), dpi=300)
    plt.close(fig)


def render_full_aircraft_plotly(config: Params | None = None,
                                output_html_path: Path | str | None = None) -> None:
    """Lưu mô hình 3D tương tác HTML tự chứa. # AI-assisted"""
    build_aircraft_figure(_params(config)).write_html(
        _path(output_html_path, "aircraft_model.html"), include_plotlyjs=True)


def build_aircraft_figure(config: Params | None = None, *, show_wing: bool = True,
                          show_fuselage: bool = True, show_grid: bool = True,
                          resolution: int = 64, wing_offset: float | None = None) -> go.Figure:
    """Tạo Plotly Figure tương tác; cánh và thân được hiển thị cùng đơn vị mét.

    `wing_offset` chỉ dịch cánh dọc x để lắp ghép trực quan, không ảnh hưởng tích phân.
    # AI-assisted: xem AI_DECLARATION.md
    """
    p = _params(config)
    n = max(16, min(int(resolution), 160))
    offset = 0.35 * p.fuselage.length if wing_offset is None else wing_offset
    fig = go.Figure()
    if show_fuselage:
        f = p.fuselage
        X, Y, Z = fuselage_surface_3d(f.length, f.radius_max, n * 2, n,
                                      f.nose_length, f.tail_length)
        fig.add_trace(go.Surface(x=X, y=Y, z=Z, name="Thân",
                                 colorscale=[[0, "#C78F35"], [1, "#F2D18A"]],
                                 showscale=False, opacity=0.92))
    if show_wing:
        u = (1 - np.cos(np.linspace(0, np.pi, n))) / 2
        v = np.linspace(-p.wing.semi_span, p.wing.semi_span, n)
        U, V = np.meshgrid(u, v)
        for side, color in (("upper", "#247BA0"), ("lower", "#8CC7DA")):
            X, Y, Z = wing_surface(U, V, p.wing.span, p.wing.chord_root,
                                   p.wing.chord_tip, p.airfoil.naca, side)
            fig.add_trace(go.Surface(x=X + offset, y=Y, z=Z,
                                     name="Cánh " + ("trên" if side == "upper" else "dưới"),
                                     colorscale=[[0, color], [1, color]],
                                     showscale=False, opacity=0.98))
    fig.update_layout(
        title="Mô hình máy bay — hình học minh họa",
        scene=dict(xaxis=dict(title="x [m]", showgrid=show_grid),
                   yaxis=dict(title="y [m]", showgrid=show_grid),
                   zaxis=dict(title="z [m]", showgrid=show_grid),
                   aspectmode="data", camera=dict(eye=dict(x=1.5, y=1.7, z=0.9))),
        margin=dict(l=0, r=0, t=42, b=0),
        paper_bgcolor="white", font=dict(family="Arial", color="#233341"),
    )
    return fig


def build_wing_figure(config: Params | None = None, *, resolution: int = 64,
                      show_grid: bool = True) -> go.Figure:
    """Tạo mô hình cánh riêng để xoay/zoom trên dashboard."""
    fig = build_aircraft_figure(config, show_fuselage=False, show_grid=show_grid,
                                resolution=resolution, wing_offset=0.0)
    fig.update_layout(title="Cánh máy bay 3D")
    return fig


def build_fuselage_figure(config: Params | None = None, *, resolution: int = 64,
                          show_grid: bool = True) -> go.Figure:
    """Tạo mô hình thân riêng để xoay/zoom trên dashboard."""
    fig = build_aircraft_figure(config, show_wing=False, show_grid=show_grid,
                                resolution=resolution)
    fig.update_layout(title="Thân máy bay 3D")
    return fig


# ==============================================================================
# PHẦN VIỆC CỦA HÀ NGỌC KHẢI (Biểu đồ khí động học 2D & Kết quả lực)
# ==============================================================================

def plot_cp_distribution(
    config: Dict[str, Any], 
    save_path: Path | str | None = None
) -> None:
    """
    Vẽ đồ thị phân bố hệ số áp suất -C_p dọc theo chiều dài dây cung x/c.
    Quy ước chuẩn khí động học: Trục tung -C_p thường đảo ngược (giá trị âm ở trên).
    
    Parameters
    ----------
    config : dict
        Tham số cấu hình
    save_path : Path | str | None
        Đường dẫn lưu ảnh (vd: results/figures/cp_distribution.png, dpi>=300)
        
    TODO (Hà Ngọc Khải):
    - Lấy phân bố Cp mặt trên và mặt dưới từ module aero.py.
    - Vẽ 2 đường cong: Mặt trên (Upper - nét liền), Mặt dưới (Lower - nét đứt).
    - Tô màu diện tích khép kín giữa 2 đường (thể hiện trực quan lực nâng tích phân).
    """
    # TODO (Hà Ngọc Khải): Viết code vẽ phân bố Cp ở đây
    raise NotImplementedError("Hà Ngọc Khải cần hoàn thiện hàm plot_cp_distribution")


def plot_lift_drag_polar(
    alpha_range_deg: np.ndarray, 
    lifts: np.ndarray, 
    drags: np.ndarray, 
    save_path: Path | str | None = None
) -> None:
    """
    Vẽ các đường đặc tính khí động học quan trọng:
    1. Đường cong hệ số lực nâng theo góc tới C_L vs alpha.
    2. Đường cong cực khí động C_L vs C_D (drag polar).
    3. Tỉ số L/D theo góc tới alpha để tìm góc tới tối ưu (max aerodynamic efficiency).
    
    Parameters
    ----------
    alpha_range_deg : np.ndarray
        Mảng các góc tới khảo sát (vd: từ 0 đến 12 độ)
    lifts, drags : np.ndarray
        Mảng lực nâng và lực cản tương ứng
    save_path : Path | str | None
        Đường dẫn lưu file ảnh
        
    TODO (Hà Ngọc Khải):
    - Vẽ đồ thị nhiều subplot (1 hàng 2 cột hoặc 1 hàng 3 cột).
    - Định dạng nhãn trục, chú thích (legend), lưới tọa độ (grid), font chuẩn cho báo cáo.
    - Lưu hình độ phân giải cao dpi>=300 vào results/figures/.
    """
    # TODO (Hà Ngọc Khải): Viết code vẽ đường đặc tính khí động học ở đây
    raise NotImplementedError("Hà Ngọc Khải cần hoàn thiện hàm plot_lift_drag_polar")
