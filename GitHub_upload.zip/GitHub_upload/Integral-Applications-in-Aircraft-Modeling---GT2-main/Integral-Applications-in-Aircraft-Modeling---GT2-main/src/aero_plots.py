"""Đồ thị báo cáo cho kết quả khí động; dùng API của Khải, không sửa aero.py.
# AI-assisted: xem AI_DECLARATION.md
"""

from __future__ import annotations

import copy
import math
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from .aero import compute_aero_forces, delta_cp, lift_slope, planform_area
from .config import Params
from .wing import WingModel


def plot_cp_report(p: Params, wing: WingModel, path: Path) -> None:
    """Lưu Cp hai mặt tại giữa nửa sải cánh thành PNG 300 dpi."""
    theta = np.linspace(0.20, math.pi - 0.01, 400)
    x = (1 - np.cos(theta)) / 2
    S = planform_area(wing)
    AR = p.wing.span**2 / S
    alpha_eff = p.alpha_rad - p.alpha_L0_rad
    dcp = delta_cp(theta, np.full_like(theta, wing.semi_span / 2),
                   wing.semi_span, alpha_eff, lift_slope(p, AR) / (2 * math.pi),
                   p.aero.span_loading)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(x, -dcp / 2, color="#146C94", label="Mặt trên")
    ax.plot(x, dcp / 2, color="#E38B29", label="Mặt dưới")
    ax.fill_between(x, -dcp / 2, dcp / 2, alpha=0.12, color="#2E86AB")
    ax.invert_yaxis()
    ax.set(title="Phân bố hệ số áp suất tại y=b/4", xlabel="x/c", ylabel="Cp")
    ax.grid(alpha=0.25)
    ax.legend()
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=300)
    plt.close(fig)


def plot_polar_report(p: Params, wing: WingModel, path: Path) -> None:
    """Lưu đặc tuyến lực nâng, cực khí động và L/D theo góc tới."""
    alphas = np.linspace(-2, 12, 15)
    lifts, drags, cls, cds = [], [], [], []
    for alpha in alphas:
        case = copy.deepcopy(p)
        case.flow.alpha_deg = float(alpha)
        result = compute_aero_forces(wing, case)
        lifts.append(result.L)
        drags.append(result.D_total)
        cls.append(result.CL)
        cds.append(result.CD)
    fig, axes = plt.subplots(1, 3, figsize=(14, 4))
    axes[0].plot(alphas, lifts, marker="o", color="#146C94")
    axes[0].set(xlabel="Góc tới α [độ]", ylabel="L [N]", title="Lực nâng")
    axes[1].plot(cds, cls, marker="o", color="#E38B29")
    axes[1].set(xlabel="CD", ylabel="CL", title="Cực khí động")
    ld = np.divide(lifts, drags, out=np.zeros(len(lifts)), where=np.abs(drags) > 1e-12)
    axes[2].plot(alphas, ld, marker="o", color="#279B80")
    axes[2].set(xlabel="Góc tới α [độ]", ylabel="L/D", title="Độ lướt")
    for ax in axes:
        ax.grid(alpha=0.25)
    fig.tight_layout()
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=300)
    plt.close(fig)
