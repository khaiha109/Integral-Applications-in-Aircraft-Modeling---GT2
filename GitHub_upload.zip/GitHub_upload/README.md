# GT2 — Mô hình cánh và thân máy bay

- `VI/`: các step 0–7 và ghi chú của Vĩ.
- `Integral-Applications-in-Aircraft-Modeling---GT2-main/`: mã dự án gốc, gồm phần khí động của Khải.

Step 7 dùng `src` của dự án gốc. Xem `VI/README.md` để biết cách chạy dashboard.
